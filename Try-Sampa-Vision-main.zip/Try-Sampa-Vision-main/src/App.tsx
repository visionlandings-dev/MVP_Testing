import { useEffect, useRef, useState, type ReactNode } from 'react';
import {
  ArrowDown,
  ArrowUpRight,
  Check,
  ChevronDown,
  Circle,
  Compass,
  Layers3,
  Mail,
  Menu,
  MessageCircle,
  MoveRight,
  PenTool,
  X,
} from 'lucide-react';

const PHONE = '5511936198011';
const EMAIL = 'try@sampa.vision';
const briefing_url = '#briefing';
const VARIANT = 'EXV-01A';
const whatsappMessage =
  'Olá. Vi a apresentação da Sampa Vision e gostaria de conversar sobre meu projeto. Referência: EXV-01.';
const whatsappUrl = `https://wa.me/${PHONE}?text=${encodeURIComponent(whatsappMessage)}`;
const emailUrl = `mailto:${EMAIL}?subject=${encodeURIComponent('Interesse — Sampa Vision')}&body=${encodeURIComponent('Olá, Sampa Vision.\n\nGostaria de compartilhar um pouco do contexto do meu projeto.\n\n')}`;

type TrackEvent =
  | 'experiment_view'
  | 'scroll_50'
  | 'scroll_90'
  | 'cta_whatsapp_click'
  | 'cta_email_click'
  | 'cta_briefing_click'
  | 'briefing_view'
  | 'briefing_start'
  | 'briefing_submit';

function track(event: TrackEvent) {
  window.dispatchEvent(
    new CustomEvent('sampa-analytics', {
      detail: { event, variant: VARIANT, utm: Object.fromEntries(new URLSearchParams(window.location.search)) },
    }),
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const briefingRef = useRef<HTMLElement>(null);
  const halfTracked = useRef(false);
  const ninetyTracked = useRef(false);

  useEffect(() => {
    track('experiment_view');
    const handleScroll = () => {
      const progress = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      if (progress >= 50 && !halfTracked.current) {
        halfTracked.current = true;
        track('scroll_50');
      }
      if (progress >= 90 && !ninetyTracked.current) {
        ninetyTracked.current = true;
        track('scroll_90');
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const element = briefingRef.current;
    if (!element) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) track('briefing_view');
    }, { threshold: 0.35 });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  const closeMenu = () => setMenuOpen(false);
  const handleBriefing = () => {
    track('cta_briefing_click');
    if (briefing_url.startsWith('#')) {
      document.querySelector(briefing_url)?.scrollIntoView({ behavior: 'smooth' });
      closeMenu();
    }
  };

  return (
    <main>
      <nav className="nav-shell" aria-label="Navegação principal">
        <a className="wordmark" href="#top" aria-label="Sampa Vision — início" onClick={closeMenu}>
          <span className="wordmark-mark">S</span>
          <span>SAMPA <b>VISION</b></span>
        </a>
        <button className="menu-button" aria-label={menuOpen ? 'Fechar menu' : 'Abrir menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        <div className={`nav-links ${menuOpen ? 'is-open' : ''}`}>
          <a href="#perspectiva" onClick={closeMenu}>Abordagem</a>
          <a href="#processo" onClick={closeMenu}>Processo</a>
          <a href="#criterio" onClick={closeMenu}>Critério</a>
          <a href="#briefing" onClick={handleBriefing}>Briefing <ArrowUpRight size={14} /></a>
          <a className="nav-cta" href={whatsappUrl} target="_blank" rel="noreferrer" onClick={() => track('cta_whatsapp_click')}>Conversar <ArrowUpRight size={15} /></a>
        </div>
      </nav>

      <section className="hero section-pad" id="top">
        <div className="hero-grid">
          <div className="hero-copy reveal">
            <p className="eyebrow">SAMPA VISION <span>/</span> EXPERIÊNCIA COMERCIAL <span>/</span> {VARIANT}</p>
            <h1>Sua landing page não precisa de mais elementos. <em>Precisa de uma decisão clara.</em></h1>
            <p className="hero-lede">Estratégia, narrativa, design e tecnologia reunidos para tornar uma proposta de valor mais clara, coerente e preparada para orientar o próximo passo.</p>
            <div className="hero-actions">
              <a className="button button-primary" href={whatsappUrl} target="_blank" rel="noreferrer" onClick={() => track('cta_whatsapp_click')}><MessageCircle size={18} /> Conversar sobre meu projeto <ArrowUpRight size={16} /></a>
              <a className="text-link" href={emailUrl} onClick={() => track('cta_email_click')}><Mail size={17} /> Enviar contexto por e-mail</a>
              <a className="text-link muted-link" href={briefing_url} onClick={handleBriefing}>Preencher briefing <ArrowUpRight size={16} /></a>
            </div>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="art-orbit orbit-one" />
            <div className="art-orbit orbit-two" />
            <div className="art-core"><span>SV</span></div>
            <div className="art-label label-top">CLAREZA <span>01</span></div>
            <div className="art-label label-bottom">DECISÃO <span>02</span></div>
            <div className="art-line line-one" /><div className="art-line line-two" />
          </div>
        </div>
        <div className="hero-footer"><span>LANÇAMENTO CONTROLADO</span><span>ESTRATÉGIA + NARRATIVA + DESIGN + TECNOLOGIA</span><ArrowDown size={17} /></div>
      </section>

      <section className="intro section-pad section-light">
        <div className="section-kicker"><span>01</span><span>O diagnóstico</span></div>
        <div className="split-heading"><h2>Nem sempre o problema está na ausência de informação.</h2><p>Às vezes, está na forma como ela é organizada. Uma página pode conter tudo o que precisa e ainda assim deixar a decisão difícil para quem chega.</p></div>
        <div className="symptoms-grid">
          {['A comunicação parece genérica.', 'A oferta é difícil de explicar.', 'A página está visualmente correta, mas não conduz a uma decisão.', 'A tecnologia existe, mas não acompanha a estratégia.'].map((item, index) => <div className="symptom" key={item}><span>0{index + 1}</span><p>{item}</p><ArrowUpRight size={17} /></div>)}
        </div>
      </section>

      <section className="perspective section-pad" id="perspectiva">
        <div className="section-kicker"><span>02</span><span>Mudança de perspectiva</span></div>
        <div className="perspective-intro"><h2>Uma landing page não é apenas uma composição visual.</h2><p>É o ponto em que o negócio precisa ser compreendido, a mensagem precisa ganhar direção, a percepção precisa transmitir confiança e a experiência precisa facilitar uma decisão.</p></div>
        <div className="perspective-grid">
          <PerspectiveCard number="01" icon={<Compass size={22} />} title="Negócio compreendido" text="A proposta precisa fazer sentido antes de ser visualmente apresentada." />
          <PerspectiveCard number="02" icon={<PenTool size={22} />} title="Mensagem com direção" text="A comunicação precisa organizar o que realmente importa." />
          <PerspectiveCard number="03" icon={<Layers3 size={22} />} title="Percepção de confiança" text="Design e linguagem precisam transmitir coerência e credibilidade." />
          <PerspectiveCard number="04" icon={<MoveRight size={22} />} title="Experiência que facilita decisão" text="A estrutura deve tornar claro qual é o próximo passo." />
        </div>
      </section>

      <section className="work section-pad section-blue">
        <div className="section-kicker light-kicker"><span>03</span><span>Formato de trabalho</span></div>
        <div className="work-heading"><h2>Um trabalho que começa <em>antes</em> do layout.</h2><p>O escopo final depende do contexto, da oferta e das necessidades do projeto. A direção nasce da conversa — não de um pacote fechado.</p></div>
        <div className="work-list">
          {['Imersão estratégica', 'Arquitetura da mensagem', 'Copy', 'Direção visual', 'Construção responsiva', 'Revisão técnica'].map((item, index) => <div className="work-item" key={item}><span>0{index + 1}</span><strong>{item}</strong><Check size={17} /></div>)}
        </div>
      </section>

      <section className="process section-pad" id="processo">
        <div className="section-kicker"><span>04</span><span>O processo</span></div>
        <div className="process-header"><h2>Da primeira conversa à experiência validada.</h2><p>Uma sequência de decisões para transformar contexto em direção — e direção em uma página que sabe para onde conduzir.</p></div>
        <div className="process-track">
          {[
            ['Conversa inicial', 'Entender o contexto, negócio, oferta e objetivo.'],
            ['Diagnóstico', 'Identificar problemas de clareza, posicionamento e comunicação.'],
            ['Direção', 'Definir narrativa, estrutura e direção estratégica.'],
            ['Construção', 'Transformar a direção em uma experiência visual e digital.'],
            ['Validação', 'Revisar e ajustar a experiência antes da entrega.'],
          ].map(([title, text], index) => <div className="process-step" key={title}><div className="step-index"><span>0{index + 1}</span><Circle size={12} fill="currentColor" /></div><h3>{title}</h3><p>{text}</p>{index < 4 && <MoveRight className="step-arrow" size={17} />}</div>)}
        </div>
      </section>

      <section className="fit section-pad section-light" id="criterio">
        <div className="section-kicker"><span>05</span><span>Critério</span></div>
        <div className="fit-grid"><div><h2>Para quem faz sentido.</h2><p className="fit-intro">Para quem entende que uma página precisa fazer mais do que existir — precisa organizar uma proposta e orientar uma conversa.</p><ul className="criteria-list">{['Empresas com uma oferta definida, mas comunicação pouco clara.', 'Profissionais que precisam apresentar melhor seus serviços.', 'Negócios que possuem audiência ou tráfego, mas cuja página não traduz adequadamente sua proposta.', 'Equipes que precisam transformar estratégia em uma experiência digital de alta qualidade.', 'Projetos em que um template genérico não é suficiente.'].map(item => <li key={item}><Check size={16} />{item}</li>)}</ul></div><div className="not-fit"><p className="eyebrow">TALVEZ NÃO SEJA O MOMENTO</p><h3>Para quem não faz sentido.</h3><ul>{['Procura apenas uma página pronta e genérica.', 'Quer resolver problemas estratégicos apenas adicionando elementos visuais.', 'Escolhe exclusivamente pelo menor preço.', 'Ainda não possui clareza mínima sobre sua oferta.'].map(item => <li key={item}>{item}</li>)}</ul></div></div>
      </section>

      <section className="briefing section-pad" id="briefing" ref={briefingRef}>
        <div className="briefing-card"><div><p className="eyebrow">06 / PRIMEIRO CONTEXTO</p><h2>Prefere começar pelo contexto?</h2><p>Se preferir, você pode compartilhar primeiro o contexto do seu projeto por meio de um briefing estruturado.</p></div><a className="button button-dark" href={briefing_url} onClick={() => track('briefing_start')}>Preencher briefing <ArrowUpRight size={17} /></a></div>
      </section>

      <section className="faq section-pad section-light">
        <div className="section-kicker"><span>07</span><span>Perguntas frequentes</span></div>
        <div className="faq-grid"><h2>Clareza também é saber o que perguntar.</h2><div>{[['É uma agência de criação de sites?', 'Não. O trabalho parte da estratégia, da mensagem e da decisão que a página precisa facilitar. A construção visual e técnica é consequência dessa direção.'], ['Vocês trabalham com qualquer projeto?', 'Cada projeto começa por uma conversa. O contexto, a oferta e o momento do negócio ajudam a entender se existe uma boa conexão para o trabalho.'], ['O escopo já vem fechado?', 'Não. O formato de trabalho é definido a partir das necessidades reais do projeto, sem transformar esta apresentação em uma promessa rígida de escopo universal.'], ['Como começo?', 'Você pode conversar pelo WhatsApp, enviar um contexto por e-mail ou começar pelo briefing estruturado.']].map(([question, answer], index) => <div className={`faq-item ${openFaq === index ? 'is-open' : ''}`} key={question}><button onClick={() => setOpenFaq(openFaq === index ? null : index)} aria-expanded={openFaq === index}><span>{question}</span><ChevronDown size={18} /></button>{openFaq === index && <p>{answer}</p>}</div>)}</div></div>
      </section>

      <section className="closing section-pad section-blue"><div className="closing-mark">SV</div><p className="eyebrow light-kicker">08 / PRÓXIMO PASSO</p><h2>Uma boa landing page não começa pelo layout. <em>Começa pela decisão que precisa ficar clara.</em></h2><p className="closing-copy">Se existe uma proposta que precisa ganhar forma, podemos começar entendendo o contexto.</p><div className="closing-actions"><a className="button button-yellow" href={whatsappUrl} target="_blank" rel="noreferrer" onClick={() => track('cta_whatsapp_click')}><MessageCircle size={18} /> Conversar sobre meu projeto <ArrowUpRight size={16} /></a><a className="closing-secondary" href={emailUrl} onClick={() => track('cta_email_click')}><Mail size={17} /> Enviar contexto por e-mail</a><a className="closing-secondary" href={briefing_url} onClick={handleBriefing}>Preencher briefing <ArrowUpRight size={16} /></a></div></section>

      <footer className="footer"><a className="wordmark" href="#top"><span className="wordmark-mark">S</span><span>SAMPA <b>VISION</b></span></a><span>EXV-01 / {VARIANT}</span><span>© 2026 SAMPA VISION</span></footer>
    </main>
  );
}

function PerspectiveCard({ number, icon, title, text }: { number: string; icon: ReactNode; title: string; text: string }) {
  return <article className="perspective-card"><div className="card-top"><span>{number}</span>{icon}</div><h3>{title}</h3><p>{text}</p></article>;
}

export default App;
